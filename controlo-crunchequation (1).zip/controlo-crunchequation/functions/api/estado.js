// Guarda e devolve o estado de cada competência.
// Ligado ao KV através da variável ESTADO, definida nas Bindings do projeto Pages.
// O Cloudflare Access trata do login antes de qualquer pedido chegar aqui.

const MES_VALIDO = /^\d{4}-\d{2}$/;

function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}

export async function onRequest(context) {
  const { request, env } = context;

  if (!env.ESTADO) {
    return json({ ok: false, erro: 'Falta ligar o KV. Nas definições do projeto, cria uma binding com o nome ESTADO.' }, 500);
  }

  const url = new URL(request.url);
  const mes = url.searchParams.get('mes') || '';
  if (!MES_VALIDO.test(mes)) {
    return json({ ok: false, erro: 'Competência inválida. Usa o formato AAAA-MM.' }, 400);
  }
  const chave = 'estado:' + mes;
  const quem = request.headers.get('cf-access-authenticated-user-email') || 'desconhecido';

  if (request.method === 'GET') {
    const bruto = await env.ESTADO.get(chave);
    if (!bruto) return json({ ok: true, estado: null, at: 0 });
    let guardado;
    try {
      guardado = JSON.parse(bruto);
    } catch (e) {
      return json({ ok: false, erro: 'O estado guardado está corrompido.' }, 500);
    }
    return json({ ok: true, estado: guardado.estado, at: guardado.at || 0, por: guardado.por || '' });
  }

  if (request.method === 'PUT') {
    let corpo;
    try {
      corpo = await request.json();
    } catch (e) {
      return json({ ok: false, erro: 'Corpo do pedido ilegível.' }, 400);
    }
    if (!corpo || typeof corpo.estado !== 'object' || corpo.estado === null) {
      return json({ ok: false, erro: 'Falta o estado.' }, 400);
    }
    const at = Date.now();
    await env.ESTADO.put(chave, JSON.stringify({ estado: corpo.estado, at, por: quem }));
    return json({ ok: true, at, por: quem });
  }

  return json({ ok: false, erro: 'Método não suportado.' }, 405);
}
